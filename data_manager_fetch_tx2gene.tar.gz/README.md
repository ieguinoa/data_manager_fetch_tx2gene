# data_manager_fetch_tx2gene
Load entries in tx2gene table with transcript to gene tables or GTF/GFF file.
